
# Tank_game
jedná se o 2d 1v1 hru s locálním multipleyerem.

Hráč 1 se ovládá pomocí w=náklon děla nahórů, s=náklon děla dólů, a=jízda doleva, d=jízda do prava, mezerník=střílení, čísla 1-4=měnění typů nábojů (4 kouřová clona)
Hráč 2  se ovládá pomocí šipky nahoru=náklon děla nahórů, šipka dólů=náklon děla dólů, šipka doleva=jízda doleva, šipka doptava=jízda do prava, 0 na numerické části=střílení, čísla na numerické části klávesnice 1-4=měnění typů nábojů (4 kouřová clona)